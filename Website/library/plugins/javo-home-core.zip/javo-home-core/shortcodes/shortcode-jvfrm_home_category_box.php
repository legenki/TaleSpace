<?php
class jvfrm_home_category_box{

	public static $shortcode_loaded = false;

	public function __construct(){
		add_shortcode( 'jvfrm_home_category_box'	, Array( __CLASS__, 'jv_featured_box_callback' ) );
		add_action( 'admin_footer'			, Array( __CLASS__, 'jvfrm_home_backend_scripts_func' ) );
	}

	public static function jvfrm_home_backend_scripts_func()
	{
		if( ! self::$shortcode_loaded )
			return;

		ob_start(); ?>
		<script type="text/javascript">jQuery(function(e){e(document).on("change","select[name='javo_featured_block_id']",function(){var t=e(this).closest(".wpb-edit-form").find('input[name="jvfrm_home_featured_block_title"]');t.val(e(this).find(":selected").text())})});</script>
		<?php ob_end_flush();
	}

	public static function jv_featured_box_callback($atts, $content=''){
		global $jvfrm_home_tso;
		extract(shortcode_atts(
			Array(
				'column' => '1-3',
				'jvfrm_home_featured_block_title' => '',
				'jvfrm_home_featured_block_description' => '',
				'text_color' => '#fff',
				'text_sub_color' => '#fff',
				'overlay_color' => '#34495e',
				'jvfrm_home_featured_block_param'	=> '',
				'attachment_other_image' => '',
				'map_template'			=> ''
			), $atts)
		);

		$output_link			= apply_filters( 'jvfrm_home_wpml_link', $map_template ).$jvfrm_home_featured_block_param;

		if($map_template==''){
			$output_link = $jvfrm_home_featured_block_param;
		}

		if($column=='1-3'){
			$jvfrm_home_this_attachemnt_meta = wp_get_attachment_image_src($attachment_other_image, 'jvfrm-home-large');
		}else if($column=='2-3'){
			$jvfrm_home_this_attachemnt_meta = wp_get_attachment_image_src($attachment_other_image, 'jvfrm-home-item-detail');
		}else{
			$jvfrm_home_this_attachemnt_meta = wp_get_attachment_image_src($attachment_other_image, true);
		}
		
		self::$shortcode_loaded = true;

		ob_start();
		?>
		<div class="javo-featured-block <?php if($column=='2-3'){echo 'javo-image-middle-size';}else if($column=='full'){echo 'javo-image-full-size';}
				else echo 'javo-image-min-size'; ?>">
			<a href="<?php echo $output_link; ?>">
				<?php
					if($attachment_other_image == '') echo $jvfrm_home_this_attachemnt_meta;
					else echo '<img src="'.$jvfrm_home_this_attachemnt_meta[0].'" alt="'.$jvfrm_home_featured_block_title.'">';
				?>
				<div class="javo-image-overlay" style="background:<?php echo $overlay_color; ?>"></div>
				<div class="javo-text-wrap">
					<span style="color:<?php echo $text_color; ?>"><?php echo $jvfrm_home_featured_block_title; ?></span>
					<div class="jvfrm_home_text_description-wrap">
						<span class="jvfrm_home_text_description" style="color:<?php echo $text_sub_color; ?>"><?php echo $jvfrm_home_featured_block_description; ?></span>
					</div>
				</div> <!--javo-text-wrap -->
			</a>
		</div>

		<?php
		wp_reset_query();
		$content = ob_get_clean();
		return $content;
	}
}
new jvfrm_home_category_box;