<?php
class jvfrm_home_slider2 extends JvfrmHome_ShortcodeParse
{
	public function output( $attr, $content='' )
	{
		$this->fixCount			= 6;
		parent::__construct( $attr ); ob_start();
		$this->sHeader();
		?>

		<div id="<?php echo $this->sID; ?>" class="shortcode-container fadein is-slider">
			<div class="shortcode-header">
				<div class="shortcode-title">
					<?php echo $this->title; ?>
				</div>
				<div class="shortcode-nav">
					<?php $this->sFilter(); ?>
				</div>
			</div>
			<div class="shortcode-output" >
				<div id="<?php echo "carousel-" . $this->sID; ?>" class="carousel slide" data-ride="carousel">
					<?php $this->loop( $this->get_post() ); ?>
					<!-- Controls -->
					<a class="left carousel-control" href="#carousel-<?php echo $this->sID; ?>" role="button" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						<span class="sr-only"><?php _e( "Previous", 'javo' ); ?></span>
					</a>
					<a class="right carousel-control" href="#carousel-<?php echo $this->sID; ?>" role="button" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						<span class="sr-only"><?php _e( "Next", 'javo' ); ?></span>
					</a>
				</div>
			</div>
		</div>

		<?php
		$this->sFooter(); return ob_get_clean();
	}

	public function loop( $queried_posts )
	{
		if( 0 < sizeof( $queried_posts ) ) :
			$strOutput	= Array();
			$strOutput[]	= "<ol class=\"carousel-indicators\">";
			for( $intCount=0;$intCount<sizeof( $queried_posts );$intCount++ )
				$strOutput[] = sprintf(
					"<li data-target=\"#%s\" data-slide-to=\"{$intCount}\" class=\"%s\"></li>", 'carousel-' . $this->sID, ( !$intCount ? 'active' :'' ));
			$strOutput[]	= "</ol>";
			$strOutput[]	="<div class=\"carousel-inner\" role=\"listbox\">";
			foreach( $queried_posts as $index=> $post ) : setup_postdata( $post );
				$strOutput[] = sprintf( "<div class=\"item%s\">", ( !$index ? ' active' : '' ) );
					$strOutput[] = get_the_post_thumbnail( $post->ID, 'full', Array( 'class' => 'data-no-lazy' ) );
					$strOutput[] = sprintf( "<div class=\"carousel-caption\">%s</div>", $post->post_title );
				$strOutput[] = "</div>";
			endforeach;
			$strOutput[]	="</div>";
			echo join( "\n", $strOutput );
		endif;
	}
}